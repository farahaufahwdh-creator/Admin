/* ============================================================
   dynamic-outbound.js
   ------------------------------------------------------------
   Membuat bagian Outbound (Package Facilities, Outbound Packages,
   dan modal detail game) di kusumaagro.netlify.app mengambil data
   dari API yang sama dengan CMS admin.

   CARA PAKAI:
   1. Taruh file ini di folder yang sama dengan index.html.
   2. Tambahkan baris ini TEPAT SEBELUM </body>, SETELAH
      <script src="dynamic-packages.js"></script>:
         <script src="dynamic-outbound.js"></script>
   3. Ganti API_BASE_URL di bawah sesuai alamat backend kamu
      (samakan dengan yang ada di dynamic-packages.js).

   CATATAN: Kalau API gagal diakses, konten statis yang sudah ada
   di HTML tetap tampil apa adanya (tidak dihapus).
============================================================ */

(function () {
  const API_BASE_URL = 'http://kusuma-agro-backend.test/index.php/api';

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatRupiah(value) {
    return 'Rp ' + Number(value || 0).toLocaleString('id-ID');
  }

  async function loadOutboundData() {
    try {
      const [facRes, pkgRes] = await Promise.all([
        fetch(`${API_BASE_URL}/facilities`),
        fetch(`${API_BASE_URL}/outbound-packages`)
      ]);
      if (!facRes.ok || !pkgRes.ok) throw new Error('HTTP ' + facRes.status + '/' + pkgRes.status);

      const facilities = await facRes.json();
      const packages = await pkgRes.json();

      if (Array.isArray(facilities) && facilities.length > 0) {
        renderFacilities(facilities);
      }
      if (Array.isArray(packages) && packages.length > 0) {
        renderOutboundPackages(packages);
        renderExperienceList(packages);
        renderOutboundModals(packages);
      }
    } catch (err) {
      console.warn('[dynamic-outbound] Gagal memuat data dari API, memakai konten statis sebagai cadangan.', err);
    }
  }

  /* ---------------- PACKAGE FACILITIES ---------------- */
  function renderFacilities(facilities) {
    const list = document.querySelector('.ob-act-list');
    if (!list) return;

    const active = facilities.filter(f => f.status === 'available');
    list.innerHTML = active.map((f, idx) => `
      <div class="ob-act-row">
        <div class="ob-act-num">${String(idx + 1).padStart(2, '0')}</div>
        <div class="ob-act-name"><h4>${escapeHtml(f.name)}</h4><span>${escapeHtml(f.capacity)}</span></div>
        <div class="ob-act-price">${formatRupiah(f.price)} / ${escapeHtml(f.unit_label || 'Orang')}</div>
        <button class="btn btn-dark liftable ob-fac-add-btn" data-name="${escapeHtml(f.name)}" data-detail="${escapeHtml((f.capacity || '') + ' - ' + formatRupiah(f.price) + '/' + (f.unit_label || 'Orang'))}">ADD TO PACK</button>
      </div>
    `).join('');

    list.querySelectorAll('.ob-fac-add-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof addToCart === 'function') {
          addToCart(btn.getAttribute('data-name'), btn.getAttribute('data-detail'));
        }
      });
    });
  }

  /* ---------------- OUTBOUND PACKAGES (3 kartu) ---------------- */
  function renderOutboundPackages(packages) {
    const grid = document.querySelector('.ob-pkg-row-layout');
    if (!grid) return;

    grid.innerHTML = packages.map(p => `
      <div class="ob-pkg-card liftable">
        <div class="ob-pkg-clickable" data-slug="${escapeHtml(p.slug)}" style="cursor:pointer;">
          <h3>${escapeHtml(p.name)}</h3>
          <p>${escapeHtml(p.short_desc)}</p>
        </div>
        <div>
          <div class="meta-info ob-pkg-clickable" data-slug="${escapeHtml(p.slug)}" style="cursor:pointer;">
            ${p.min_pax_note ? `<div class="meta-item">${escapeHtml(p.min_pax_note.split(':')[0] || 'Kapasitas Minimum')}: <strong>${escapeHtml((p.min_pax_note.split(':')[1] || p.min_pax_note).trim())}</strong></div>` : ''}
            ${p.duration_note ? `<div class="meta-item">Durasi Utama: <strong>${escapeHtml(p.duration_note)}</strong></div>` : ''}
          </div>
          <div style="display:flex; gap:8px;">
            <button class="btn btn-outline ob-pkg-add-btn" style="flex:1; justify-content:center; border-color:var(--forest-900); color:var(--forest-900);"
              data-name="${escapeHtml(p.name)}" data-subtitle="${escapeHtml(p.cart_subtitle || p.name)}">ADD TO PACK</button>
            <button class="btn btn-dark ob-pkg-view-btn" style="padding:12px;" data-slug="${escapeHtml(p.slug)}">➔</button>
          </div>
        </div>
      </div>
    `).join('');

    grid.querySelectorAll('.ob-pkg-clickable, .ob-pkg-view-btn').forEach(el => {
      el.addEventListener('click', () => {
        if (typeof openObPackage === 'function') openObPackage(el.getAttribute('data-slug'));
      });
    });
    grid.querySelectorAll('.ob-pkg-add-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof addToCart === 'function') {
          addToCart(btn.getAttribute('data-name'), btn.getAttribute('data-subtitle'));
        }
      });
    });
  }

  /* ---------------- Mini list di section "Our Experience" ---------------- */
  function renderExperienceList(packages) {
    const ul = document.querySelector('.ob-exp-box ul');
    if (!ul) return;

    ul.innerHTML = packages.map(p => `
      <li data-slug="${escapeHtml(p.slug)}" style="cursor:pointer;">${escapeHtml(p.name)}${p.min_pax_note ? `<span class="tag">${escapeHtml((p.min_pax_note.split(':')[1] || p.min_pax_note).trim())}</span>` : ''}</li>
    `).join('');

    ul.querySelectorAll('li').forEach(li => {
      li.addEventListener('click', () => {
        if (typeof openObPackage === 'function') openObPackage(li.getAttribute('data-slug'));
      });
    });
  }

  /* ---------------- Modal detail per paket (kategori + tabel game) ---------------- */
  function renderOutboundModals(packages) {
    packages.forEach(p => {
      const old = document.getElementById(p.slug);
      if (old) old.remove();
    });

    packages.forEach(p => {
      const modal = document.createElement('div');
      modal.id = p.slug;
      modal.className = 'package-detail-page';

      const categoriesHtml = (p.categories || []).map(cat => {
        const rowsHtml = (cat.rows || []).map(r => `
          <tr>
            <td class="facility-cell"><strong>${escapeHtml(r.col1)}</strong></td>
            <td>${escapeHtml(r.col2)}</td>
            <td class="center-td">${escapeHtml(r.col3)}</td>
            <td>${escapeHtml(r.col4)}</td>
          </tr>
        `).join('');

        return `
          <div class="modal-category-title">${escapeHtml(cat.title)}</div>
          <div class="table-scroll">
            <table class="price-table">
              <thead>
                <tr>
                  <th>${escapeHtml(cat.col1_label)}</th>
                  <th>${escapeHtml(cat.col2_label)}</th>
                  <th class="center-th">${escapeHtml(cat.col3_label)}</th>
                  <th>${escapeHtml(cat.col4_label)}</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
          </div>
        `;
      }).join('');

      modal.innerHTML = `
        <div class="modal-card">
          <div class="modal-header">
            <h3>${escapeHtml((p.name || '').toUpperCase())}</h3>
            <div class="modal-close-x">✕</div>
          </div>
          <div class="modal-body">
            <div class="price-group">
              <div class="price-group-head">
                ${p.facilities_note ? `<p><strong>Fasilitas:</strong> ${escapeHtml(p.facilities_note)}</p>` : ''}
                ${p.min_pax_note ? `<div class="effective" style="margin-top:8px; font-weight:500; color: var(--gold);">${escapeHtml(p.min_pax_note)}</div>` : ''}
              </div>
              ${categoriesHtml}
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(modal);

      modal.addEventListener('click', (e) => {
        if (e.target === modal && typeof closeObPackage === 'function') closeObPackage(p.slug);
      });
      modal.querySelector('.modal-close-x').addEventListener('click', () => {
        if (typeof closeObPackage === 'function') closeObPackage(p.slug);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', loadOutboundData);
})();
