/* ============================================================
   dynamic-inquiries.js
   ------------------------------------------------------------
   1. Mengirim form "Stay Connected" (nama/email/pesan) ke database
      lewat endpoint /inquiries.
   2. Mencatat isi keranjang WA ke database SETIAP kali tombol
      "TINDAK LANJUTI KE WA" diklik -- tanpa mengubah fungsi
      checkoutToWhatsApp() aslinya di script utama.

   CARA PAKAI:
   1. Taruh file ini di folder yang sama dengan index.html.
   2. Tambahkan baris ini TEPAT SEBELUM </body>, SETELAH semua
      script dynamic-*.js yang lain:
         <script src="dynamic-inquiries.js"></script>
   3. Ganti API_BASE_URL di bawah sesuai alamat backend kamu.
   4. Update HTML form "Stay Connected" (lihat instruksi terpisah)
      supaya ada kolom Nama & Pesan, bukan cuma Email.
============================================================ */

const INQUIRY_API_BASE_URL = 'http://kusuma-agro-backend.test/index.php/api';

// Dipanggil dari atribut onsubmit="return submitContactForm(event, this)"
// pada form "Stay Connected" di HTML.
async function submitContactForm(event, form) {
    event.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'MENGIRIM...';

    const payload = {
        type: 'contact',
        name: form.name ? form.name.value : '',
        email: form.email ? form.email.value : '',
        message: form.message ? form.message.value : ''
    };

    try {
        const res = await fetch(`${INQUIRY_API_BASE_URL}/inquiries`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);

        btn.textContent = 'TERKIRIM ✓';
        form.reset();
        setTimeout(() => { btn.textContent = originalText; }, 3000);
    } catch (err) {
        console.warn('[dynamic-inquiries] Gagal mengirim pesan kontak.', err);
        btn.textContent = 'GAGAL, COBA LAGI';
        setTimeout(() => { btn.textContent = originalText; }, 3000);
    }
    return false;
}

// Sisipkan pencatatan ke database ke fungsi checkoutToWhatsApp yang SUDAH ADA,
// tanpa perlu mengubah kodenya sama sekali.
document.addEventListener('DOMContentLoaded', function () {
    if (typeof checkoutToWhatsApp !== 'function') {
        console.warn('[dynamic-inquiries] Fungsi checkoutToWhatsApp tidak ditemukan, pencatatan checkout dilewati.');
        return;
    }

    const originalCheckout = checkoutToWhatsApp;

    checkoutToWhatsApp = function () {
        try {
            if (typeof obCartList !== 'undefined' && Array.isArray(obCartList) && obCartList.length > 0) {
                const summary = obCartList.map(item => `${item.name} (${item.details})`).join('; ');
                fetch(`${INQUIRY_API_BASE_URL}/inquiries`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'cart_checkout', items_summary: summary })
                }).catch(err => console.warn('[dynamic-inquiries] Gagal mencatat checkout ke database.', err));
            }
        } catch (e) {
            console.warn('[dynamic-inquiries] Error saat mencoba mencatat checkout.', e);
        }

        // Tetap jalankan perilaku asli (buka WhatsApp) apapun yang terjadi di atas
        return originalCheckout.apply(this, arguments);
    };
});
