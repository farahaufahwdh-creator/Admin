/* ============================================================
   dynamic-fnb.js
   ------------------------------------------------------------
   Membuat bagian Food & Coffee (Kedai Apel, Kedai Strawberry,
   Kedai Alamanda) di kusumaagro.netlify.app mengambil data
   dari API yang sama dengan CMS admin (tab F&B Menu).

   CARA PAKAI:
   1. Taruh file ini di folder yang sama dengan index.html.
   2. Tambahkan baris ini TEPAT SEBELUM </body>, setelah
      dynamic-packages.js dan dynamic-outbound.js:
         <script src="dynamic-fnb.js"></script>
   3. Ganti API_BASE_URL di bawah sesuai alamat backend kamu
      (samakan dengan file dynamic-* lainnya).

   CATATAN: Kalau API gagal diakses, konten statis yang sudah ada
   di HTML tetap tampil apa adanya (tidak dihapus).
============================================================ */

(function () {
  const API_BASE_URL = 'http://kusuma-agro-backend.test/index.php/api';

  // Pemetaan venue di database -> id section di HTML situs
  const VENUE_TO_SECTION = {
    'apple-house': 'fc-apel',
    'strawberry-house': 'fc-strawberry',
    'kedai-alamanda': 'fc-alamanda'
  };

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatRupiah(value) {
    return 'Rp ' + Number(value || 0).toLocaleString('id-ID');
  }

  async function loadFnbMenu() {
    try {
      const res = await fetch(`${API_BASE_URL}/fnb-menu`);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const items = await res.json();
      if (!Array.isArray(items) || items.length === 0) return;

      renderVenue('apple-house', items);
      renderVenue('strawberry-house', items);
      renderVenue('kedai-alamanda', items);
    } catch (err) {
      console.warn('[dynamic-fnb] Gagal memuat data dari API, memakai konten statis sebagai cadangan.', err);
    }
  }

  function renderVenue(venueKey, allItems) {
    const sectionId = VENUE_TO_SECTION[venueKey];
    const section = document.getElementById(sectionId);
    if (!section) return;

    const grid = section.querySelector('.fc-menu-grid');
    if (!grid) return;

    // Hanya tampilkan menu yang statusnya available atau seasonal (bukan out-of-stock)
    const items = allItems.filter(i => i.venue === venueKey && i.status !== 'out-of-stock');
    if (items.length === 0) return; // biarkan konten statis kalau memang kosong

    grid.innerHTML = items.map(i => `
      <div class="fc-item-card">
        <div class="img"><img src="${i.image_url ? escapeHtml(i.image_url) : 'https://picsum.photos/seed/menu-' + i.id + '/400/300'}" alt="${escapeHtml(i.name)}"></div>
        <div class="info">
          <h5>${escapeHtml(i.name)}</h5>
          <p>${escapeHtml(i.desc)}</p>
          <div class="price-tag">${formatRupiah(i.price)}</div>
        </div>
      </div>
    `).join('');
  }

  document.addEventListener('DOMContentLoaded', loadFnbMenu);
})();
