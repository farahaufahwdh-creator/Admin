/* ============================================================
   dynamic-site-images.js
   ------------------------------------------------------------
   Mengganti SEMUA gambar dekoratif di situs (hero, galeri, foto
   Outbound & Food/Coffee, dll -- di luar Packages & F&B yang
   sudah punya sistemnya sendiri) sesuai data dari CMS admin.

   CARA KERJA: script ini mencari <img> di halaman berdasarkan
   teks alt="..." yang SUDAH ADA di HTML kamu (tidak perlu diubah
   sama sekali), lalu mengganti src-nya sesuai data dari database.

   CARA PAKAI:
   1. Taruh file ini di folder yang sama dengan index.html.
   2. Tambahkan baris ini TEPAT SEBELUM </body>, di baris PALING
      TERAKHIR (setelah dynamic-packages.js, dynamic-outbound.js,
      dynamic-fnb.js):
         <script src="dynamic-site-images.js"></script>
   3. Ganti API_BASE_URL di bawah sesuai alamat backend kamu.

   CATATAN: Kalau API gagal diakses, atau alt text tidak ketemu
   cocok, gambar aslinya tetap tampil apa adanya (tidak dihapus).
============================================================ */

(function () {
  const API_BASE_URL = 'http://kusuma-agro-backend.test/index.php/api';

  async function loadSiteImages() {
    try {
      const res = await fetch(`${API_BASE_URL}/site-images`);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const images = await res.json();
      if (!Array.isArray(images) || images.length === 0) return;

      images.forEach(item => {
        // Cari <img alt="..."> yang cocok persis dengan alt_match dari database
        const img = document.querySelector(`img[alt="${cssEscapeAttr(item.alt_match)}"]`);
        if (img && item.image_url) {
          img.src = item.image_url;
        }
      });
    } catch (err) {
      console.warn('[dynamic-site-images] Gagal memuat data dari API, memakai gambar statis sebagai cadangan.', err);
    }
  }

  // Escape sederhana untuk nilai atribut dipakai di dalam querySelector
  function cssEscapeAttr(value) {
    return String(value).replace(/"/g, '\\"');
  }

  document.addEventListener('DOMContentLoaded', loadSiteImages);
})();
