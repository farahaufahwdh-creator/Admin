(function () {
  'use strict';

  // Alamat backend CodeIgniter
  const API_BASE_URL = 'http://kusuma-agro-backend.test/index.php/api';

  // 1. FUNGSI AMAN ESCAPE HTML
  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // 2. ENGINE PEMBUAT SLIDER DAN TOMBOL PANAH (‹ DAN ›)
  function createCardSlider(images, fallbackImage, packageId) {
    let imgList = [];
    
    // Jika ada banyak gambar di gallery_images, pakai itu
    if (images && images.length > 0) {
      imgList = images;
    } else if (fallbackImage) {
      // Jika kosong, gunakan image_url utama sebagai single image
      imgList = [fallbackImage];
    }

    if (imgList.length === 0) {
      return `<img src="https://picsum.photos/seed/placeholder/600/400" alt="Placeholder">`;
    }
    
    // Jika gambarnya cuma 1, langsung tampilkan biasa tanpa panah navigasi
    if (imgList.length === 1) {
      return `<img src="${escapeHtml(imgList[0])}" alt="Package Image" style="width:100%; height:100%; object-fit:cover;">`;
    }

    // Jika gambarnya lebih dari 1, buat struktur slide + tombol panah melayang
    const slidesHtml = imgList.map((img, idx) => `
      <div class="my-slide slide-pkg-${packageId}" style="display: ${idx === 0 ? 'block' : 'none'}; width:100%; height:100%;">
        <img src="${escapeHtml(img)}" alt="Slide" style="width:100%; height:100%; object-fit:cover;">
      </div>
    `).join('');

    return `
      <div class="custom-slider-container" style="position:relative; width:100%; height:100%; overflow:hidden;">
        ${slidesHtml}
        <button class="slider-arrow prev" onclick="changeSlide(${packageId}, -1, event)">‹</button>
        <button class="slider-arrow next" onclick="changeSlide(${packageId}, 1, event)">›</button>
      </div>
    `;
  }

  // 3. FUNGSI GLOBAL PENGGERAK PANAH SLIDER (DENGAN STOP PROPAGATION)
  window.changeSlide = function(packageId, direction, event) {
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }
    
    const slides = document.querySelectorAll(`.slide-pkg-${packageId}`);
    if (!slides || slides.length === 0) return;

    let activeIdx = -1;
    slides.forEach((slide, idx) => {
      if (slide.style.display === 'block') activeIdx = idx;
    });

    if (activeIdx === -1) return;

    slides[activeIdx].style.display = 'none';
    let nextIdx = activeIdx + direction;
    if (nextIdx >= slides.length) nextIdx = 0;
    if (nextIdx < 0) nextIdx = slides.length - 1;

    slides[nextIdx].style.display = 'block';
  };

  // 4. LOAD DATA DARI API BACKEND
  async function loadPackages() {
    try {
      const res = await fetch(`${API_BASE_URL}/packages`);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const packages = await res.json();
      if (!Array.isArray(packages) || packages.length === 0) return;

      renderPackageGrid(packages);
      renderPackageModals(packages);
    } catch (err) {
      console.warn('[dynamic-packages] Gagal memuat data dari API, memakai konten statis sebagai cadangan.', err);
    }
  }

  // 5. RENDER GRID PEMBAGI LAYOUT DENGAN SLIDER DINAMIS
  function renderPackageGrid(packages) {
    const grid = document.querySelector('.pkg-grid');
    if (!grid) return;

    const featuredPackages = packages.filter(p => Number(p.is_featured) === 1);
    const regularPackages = packages.filter(p => Number(p.is_featured) !== 1);
    const totalFeatured = featuredPackages.length;

    let htmlContent = '';

    if (totalFeatured === 1) {
      grid.className = 'pkg-grid layout-split'; 
      const featured = featuredPackages[0];

      const featureHtml = `
        <div class="pkg-feature liftable">
          <div class="img pkg-clickable" data-slug="${escapeHtml(featured.slug)}">
            ${createCardSlider(featured.gallery_images, featured.image_url, featured.id)}
          </div>
          <div class="info">
            ${featured.badge ? `<div class="badge pkg-clickable" data-slug="${escapeHtml(featured.slug)}">${escapeHtml(featured.badge)}</div>` : ''}
            <div class="pkg-clickable" data-slug="${escapeHtml(featured.slug)}">
              <h3>${escapeHtml(featured.name)}</h3>
              <p>${escapeHtml(featured.short_desc)}</p>
            </div>
            <div class="pkg-bottom" style="display:flex; gap:8px; width:100%; justify-content:flex-end;">
              <button class="btn btn-outline pkg-add-btn" style="border-color:var(--forest-900); color:var(--forest-900);"
                data-name="${escapeHtml(featured.name)}" data-subtitle="${escapeHtml(featured.cart_subtitle || featured.name)}">ADD TO PACK</button>
              <button class="btn btn-dark pkg-view-btn" data-slug="${escapeHtml(featured.slug)}">VIEW DETAILS</button>
            </div>
          </div>
        </div>
      `;

      const smallHtml = regularPackages.map(p => renderSmallCard(p)).join('');
      htmlContent = featureHtml + `<div class="pkg-side">${smallHtml}</div>`;
    } 
    else if (totalFeatured > 1) {
      grid.className = 'pkg-grid layout-multi-mix';
      const bigCardsHtml = featuredPackages.map(p => renderBigCard(p)).join('');
      const smallCardsHtml = regularPackages.map(p => renderSmallCard(p)).join('');
      
      htmlContent = `
        <div class="pkg-featured-row">${bigCardsHtml}</div>
        ${regularPackages.length > 0 ? `<div class="pkg-regular-row">${smallCardsHtml}</div>` : ''}
      `;
    }
    else {
      grid.className = 'pkg-grid layout-all-small';
      htmlContent = packages.map(p => renderSmallCard(p)).join('');
    }

    grid.innerHTML = htmlContent;

    // Event Klik Modal Detail
    grid.querySelectorAll('.pkg-clickable, .pkg-view-btn').forEach(el => {
      el.style.cursor = 'pointer';
      el.addEventListener('click', (e) => {
        if (e.target.classList.contains('slider-arrow')) return;
        if (typeof openPackage === 'function') openPackage(el.getAttribute('data-slug'));
      });
    });

    // Event Tambah Wishlist Keranjang
    grid.querySelectorAll('.pkg-add-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof addToCart === 'function') {
          addToCart(btn.getAttribute('data-name'), btn.getAttribute('data-subtitle'));
        }
      });
    });
  }

  function renderBigCard(p) {
    return `
      <div class="pkg-feature liftable">
        <div class="img pkg-clickable" data-slug="${escapeHtml(p.slug)}">
          ${createCardSlider(p.gallery_images, p.image_url, p.id)}
        </div>
        <div class="info">
          ${p.badge ? `<div class="badge pkg-clickable" data-slug="${escapeHtml(p.slug)}">${escapeHtml(p.badge)}</div>` : ''}
          <div class="pkg-clickable" data-slug="${escapeHtml(p.slug)}">
            <h3>${escapeHtml(p.name)}</h3>
            <p>${escapeHtml(p.short_desc)}</p>
          </div>
          <div class="pkg-bottom" style="display:flex; gap:8px; width:100%; justify-content:flex-end; align-items:center; margin-top:auto; padding-top:16px;">
            ${p.min_pax_note ? `<span class="eyebrow" style="color: var(--gold); font-weight:600; margin-right: auto; font-size:0.65rem;">${escapeHtml(p.min_pax_note)}</span>` : '<span style="margin-right:auto;"></span>'}
            <button class="btn btn-outline pkg-add-btn" style="border-color:var(--forest-900); color:var(--forest-900); padding: 10px 18px; font-size: 0.76rem;"
              data-name="${escapeHtml(p.name)}" data-subtitle="${escapeHtml(p.cart_subtitle || p.name)}">ADD TO PACK</button>
            <button class="btn btn-dark pkg-view-btn" style="padding: 10px 18px; font-size: 0.76rem;" data-slug="${escapeHtml(p.slug)}">VIEW DETAILS</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderSmallCard(p) {
    return `
      <div class="pkg-small liftable">
        <div class="img pkg-clickable" data-slug="${escapeHtml(p.slug)}">
          ${createCardSlider(p.gallery_images, p.image_url, p.id)}
        </div>
        <div class="info" style="position: relative;">
          ${p.badge ? `<div class="badge pkg-clickable" style="position: absolute; top: 14px; right: 20px; transform:none;">${escapeHtml(p.badge)}</div>` : ''}
          <h4 class="pkg-clickable" data-slug="${escapeHtml(p.slug)}">${escapeHtml(p.name)}</h4>
          <p class="pkg-clickable" data-slug="${escapeHtml(p.slug)}">${escapeHtml(p.short_desc)}</p>
          <div class="pkg-bottom" style="display:flex; gap:6px; margin-top:8px; align-items:center; width:100%;">
            ${p.min_pax_note ? `<span class="eyebrow" style="color: var(--gold); font-weight:600; margin-right: auto; font-size:0.65rem;">${escapeHtml(p.min_pax_note)}</span>` : '<span style="margin-right:auto;"></span>'}
            <button class="btn btn-outline pkg-add-btn" style="padding: 8px 14px; font-size: 0.74rem; border-color:var(--forest-900); color:var(--forest-900);"
              data-name="${escapeHtml(p.name)}" data-subtitle="${escapeHtml(p.cart_subtitle || p.name)}">ADD TO PACK</button>
            <button class="btn btn-dark pkg-view-btn" style="padding: 8px 14px; font-size: 0.74rem;" data-slug="${escapeHtml(p.slug)}">VIEW</button>
          </div>
        </div>
      </div>
    `;
  }

  // 6. RENDER POP-UP MODAL HARGA
  function renderPackageModals(packages) {
    packages.forEach(p => {
      const old = document.getElementById(p.slug);
      if (old) old.remove();
    });

    packages.forEach(p => {
      const modal = document.createElement('div');
      modal.id = p.slug;
      modal.className = 'package-detail-page';

      const rowsHtml = (p.rows || []).map(r => `
        <tr>
          <td>${escapeHtml(r.col1)}</td>
          <td class="facility-cell">${escapeHtml(r.col2)}</td>
          <td>${escapeHtml(r.col3)}</td>
          <td>${escapeHtml(r.col4)}</td>
        </tr>
      `).join('');

      modal.innerHTML = `
        <div class="modal-card">
          <div class="modal-header">
            <h3>${escapeHtml((p.name || '').toUpperCase())}</h3>
            <div class="modal-close-x">✕</div>
          </div>
          <div class="modal-body">
            <div class="price-group">
              <div class="price-group-head">
                ${p.effective_date ? `<div class="effective">Effective: ${escapeHtml(p.effective_date)}</div>` : ''}
              </div>
              <div class="table-scroll">
                <table class="price-table">
                  <thead>
                    <tr>
                      <th>${escapeHtml(p.col1_label)}</th>
                      <th>${escapeHtml(p.col2_label)}</th>
                      <th>${escapeHtml(p.col3_label)}</th>
                      <th>${escapeHtml(p.col4_label)}</th>
                    </tr>
                  </thead>
                  <tbody>${rowsHtml}</tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(modal);

      modal.addEventListener('click', (e) => {
        if (e.target === modal && typeof closePackage === 'function') closePackage(p.slug);
      });
      modal.querySelector('.modal-close-x').addEventListener('click', () => {
        if (typeof closePackage === 'function') closePackage(p.slug);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', loadPackages);
})();