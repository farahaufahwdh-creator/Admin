-- ============================================================
-- TABEL: inquiries (pesan kontak + riwayat checkout keranjang WA)
-- ============================================================

CREATE TABLE IF NOT EXISTS `inquiries` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `type` ENUM('contact','cart_checkout') NOT NULL DEFAULT 'contact',
  `name` VARCHAR(150) DEFAULT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `phone` VARCHAR(50) DEFAULT NULL,
  `message` TEXT DEFAULT NULL,
  `items_summary` TEXT DEFAULT NULL,
  `status` ENUM('new','replied','closed') NOT NULL DEFAULT 'new',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Contoh data (boleh dihapus manual nanti dari CMS)
INSERT INTO `inquiries` (`type`, `name`, `email`, `message`, `status`) VALUES
('contact', 'Budi Santoso', 'budi@example.com', 'Halo, apakah tersedia paket untuk rombongan 50 orang di bulan depan?', 'new');
