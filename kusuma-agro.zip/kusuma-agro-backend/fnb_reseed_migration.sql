-- ============================================================
-- RESEED tabel fnb_menu_items dengan menu ASLI dari situs
-- kusumaagro.netlify.app (Apple House, Strawberry House, Kedai Alamanda)
-- ============================================================

DROP TABLE IF EXISTS `fnb_menu_items`;

CREATE TABLE `fnb_menu_items` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `venue` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `desc` VARCHAR(255) DEFAULT NULL,
  `category` VARCHAR(50) DEFAULT NULL,
  `price` INT UNSIGNED NOT NULL DEFAULT 0,
  `stock` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('available','seasonal','out-of-stock') NOT NULL DEFAULT 'available',
  `is_promo` TINYINT(1) NOT NULL DEFAULT 0,
  `is_low_stock` TINYINT(1) NOT NULL DEFAULT 0,
  `today_sold` INT UNSIGNED NOT NULL DEFAULT 0,
  `display_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `fnb_menu_items`
  (`venue`, `name`, `desc`, `category`, `price`, `stock`, `status`, `is_promo`, `is_low_stock`, `today_sold`, `display_order`)
VALUES
('apple-house', 'Signature Apple Pie',
 'Pai renyah isi selai apel Batu kayu manis hangat disajikan dengan es krim vanila.',
 'FOOD', 35000, 40, 'available', 1, 0, 20, 1),

('apple-house', 'Fresh Apple Juice',
 '100% perasan murni buah apel segar alami pilihan langsung dari pohon kebun.',
 'BEVERAGE', 22000, 100, 'available', 0, 0, 35, 2),

('strawberry-house', 'Strawberry Premium Pancake',
 'Pancake lembut hangat berlapis krim dengan limpahan saus strawberry segar.',
 'FOOD', 38000, 30, 'available', 1, 0, 18, 1),

('strawberry-house', 'Strawberry Creamy Milkshake',
 'Perpaduan susu segar pilihan, es krim vanilla, dan potongan buah strawberry ranum.',
 'BEVERAGE', 25000, 60, 'available', 0, 0, 24, 2),

('kedai-alamanda', 'Nasi Goreng Rempah Alamanda',
 'Nasi goreng kaya rempah khas dengan pelengkap ayam krispi, telur dadar, dan kerupuk udang gurih.',
 'FOOD', 45000, 50, 'available', 0, 0, 16, 1),

('kedai-alamanda', 'Café Latte Premium',
 'Ekstraksi espresso arabika dengan kombinasi foam susu bertekstur lembut sempurna.',
 'BEVERAGE', 28000, 80, 'available', 1, 0, 28, 2);
