-- ============================================================
-- MIGRASI: Facilities (update) + Outbound Packages (baru)
-- ============================================================

-- ---- FACILITIES: buat ulang dengan kolom lengkap + data asli ----
DROP TABLE IF EXISTS `facilities`;

CREATE TABLE `facilities` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `zone` VARCHAR(150) DEFAULT NULL,
  `capacity` VARCHAR(50) DEFAULT NULL,
  `price` INT UNSIGNED NOT NULL DEFAULT 0,
  `unit_label` VARCHAR(30) NOT NULL DEFAULT 'Orang',
  `status` ENUM('available','maintenance') NOT NULL DEFAULT 'available',
  `display_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `facilities` (`name`, `zone`, `capacity`, `price`, `unit_label`, `status`, `display_order`) VALUES
('Paintball Combat', NULL, 'Min. 20 Orang', 180000, 'Orang', 'available', 1),
('Air Softgun Battle', NULL, 'Min. 10 Orang', 120000, 'Orang', 'available', 2),
('Flying Fox', NULL, 'Per Orang', 20000, 'Orang', 'available', 3),
('Mobil Komodo (ATV Mini Off-Road)', NULL, 'Per Unit / 2 Putaran', 100000, 'Unit', 'available', 4),
('Motor Cross Funride', NULL, 'Per Orang', 50000, 'Orang', 'available', 5),
('Pony Horse Ride', NULL, 'Per Orang', 10000, 'Orang', 'available', 6);


-- ---- OUTBOUND PACKAGES (paket + kategori game + baris game) ----
CREATE TABLE IF NOT EXISTS `outbound_packages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `short_desc` TEXT DEFAULT NULL,
  `facilities_note` TEXT DEFAULT NULL,
  `min_pax_note` VARCHAR(50) DEFAULT NULL,
  `duration_note` VARCHAR(50) DEFAULT NULL,
  `cart_subtitle` VARCHAR(150) DEFAULT NULL,
  `display_order` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `outbound_categories` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `package_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `col1_label` VARCHAR(50) NOT NULL DEFAULT 'Nama Game',
  `col2_label` VARCHAR(50) NOT NULL DEFAULT 'Learning & Goal',
  `col3_label` VARCHAR(50) NOT NULL DEFAULT 'Durasi',
  `col4_label` VARCHAR(50) NOT NULL DEFAULT 'Keterangan',
  `sort_order` INT NOT NULL DEFAULT 0,
  FOREIGN KEY (`package_id`) REFERENCES `outbound_packages`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `outbound_category_rows` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT UNSIGNED NOT NULL,
  `col1` VARCHAR(150) DEFAULT NULL,
  `col2` TEXT DEFAULT NULL,
  `col3` VARCHAR(100) DEFAULT NULL,
  `col4` TEXT DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  FOREIGN KEY (`category_id`) REFERENCES `outbound_categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Isi 3 Outbound Packages asli ----
INSERT INTO `outbound_packages` (`id`, `slug`, `name`, `short_desc`, `facilities_note`, `min_pax_note`, `duration_note`, `cart_subtitle`, `display_order`) VALUES
(1, 'ob-modal-adult', 'Outbound Dewasa',
 'Program interaktif guna mempererat kerja sama kelompok, kepemimpinan, dan komunikasi efektif melalui simulasi problem solving terpandu di alam bebas.',
 'Wisata petik 2 Apel/Jambu, Juice, Snack Box, Lunch Box, Mineral Water, Adventure.',
 'Kapasitas Minimum: 30 Orang', '±4-6 Jam', 'Paket Terpadu (Min. 30 Orang)', 1),

(2, 'ob-modal-students', 'Outbound SMP & SMA',
 'Dirancang untuk menumbuhkan jiwa kepemimpinan individu, kemandirian siswa, rasa tanggung jawab sosial, serta keberanian mengambil keputusan positif.',
 'Wisata petik 2 Apel/Jambu, Juice, Lunch Box, Mineral Water, Waterpark, Adventure.',
 'Kapasitas Minimum: 30 Siswa', '±4-6 Jam', 'Paket Sekolah (Min. 30 Siswa)', 2),

(3, 'ob-modal-kids', 'Outbound Kids (TK & SD)',
 'Eksplorasi ceria motorik anak usia dini melalui pengenalan alam luar ruangan, ketangkasan fisik ringan, serta edukasi budidaya tanaman hortikultura.',
 'Wisata petik 2 Apel/Jambu, Juice, Lunch Box, Mineral Water, Waterpark, Adventure.',
 'Kapasitas Minimum: 30 Anak', '3 - 4 Jam', 'Paket Anak (Min. 30 Anak)', 3);

-- ---- Kategori + baris: Outbound Dewasa ----
INSERT INTO `outbound_categories` (`id`, `package_id`, `title`, `col1_label`, `col2_label`, `col3_label`, `col4_label`, `sort_order`) VALUES
(1, 1, 'A. Ice Breaking', 'Nama Game & Deskripsi', 'Learning & Goal', 'Durasi', 'Keterangan Tambahan', 0),
(2, 1, 'B. Outbound Games', 'Nama Game & Deskripsi', 'Learning & Goal', 'Durasi', 'Keterangan Tambahan', 1);

INSERT INTO `outbound_category_rows` (`category_id`, `col1`, `col2`, `col3`, `col4`, `sort_order`) VALUES
(1, 'Chicken Dance Brands Game: Membuat lingkaran besar lalu menggoyang-goyang pinggulnya sesuai perintah instruktur.', 'Team work, decision making', '±30 Menit', 'Pencairan suasana awal tim (60 pax)', 0),
(1, 'People to People: Mencari pasangan masing-masing sambil berpegangan sesuai dengan hitungan instruktur.', 'Ketahanan terhadap stretching', '±45 Menit', 'Membangun keakraban & adaptasi kilat', 1),
(1, 'Opposite: Gerakan bersama-sama dengan satu team dengan hitungan lawan kata yang sebenarnya.', 'Team Work, Strategy, Group Strategy, Planning dan strategy', '±30 Menit', 'Melatih konsentrasi tingkat tinggi', 2),

(2, 'Traffic Jam: Berpindah dari satu sisi ke sisi yang lain sesuai dengan instruksi.', 'Menumbuhkan jiwa leadership', '±60 Menit', 'Kriteria Peserta: Company, Instansi, Corporate', 0),
(2, 'Ufo Alien: Memindahkan bola diatas nampan dari satu ke tempat lain.', 'Kekompakan dan konsentrasi team', '±45 Menit', 'Kriteria Peserta: Company, Instansi, Corporate', 1),
(2, 'Water Tower: Berusaha mengisi air dalam drum, yang terdapat lubang lubang kecil hingga penuh.', 'Kekompakan dan konsentrasi team', '±60 Menit', 'Kriteria Peserta: Company, Instansi, Corporate', 2),
(2, 'Helium Stick: Mengikuti ritme naik dan turunnya bambu dengan menggunakan jari telunjuk tiap peserta secara bersamaan.', 'Team work, strategy', '±30 Menit', 'Kriteria Peserta: Company, Instansi, Corporate', 3);

-- ---- Kategori + baris: Outbound SMP & SMA (1 kategori umum, tanpa judul huruf) ----
INSERT INTO `outbound_categories` (`id`, `package_id`, `title`, `col1_label`, `col2_label`, `col3_label`, `col4_label`, `sort_order`) VALUES
(3, 2, 'Rangkaian Game', 'Nama Game & Deskripsi', 'Learning & Goal', 'Durasi / Keterangan', 'Keterangan', 0);

INSERT INTO `outbound_category_rows` (`category_id`, `col1`, `col2`, `col3`, `col4`, `sort_order`) VALUES
(3, 'Ball n Pipe: Memindahkan bola pingpong dengan menggunakan paralon dari satu tempat ke tempat yang lain.', 'Team work, tanggung jawab', 'Outbound ±4 Jam / 60 pax', '', 0),
(3, 'Labirin: Berusaha memasukkan bola pada sebuah lubang.', 'Leadership, kekompakan inisiatif', 'Outbound + makan + wisata + ±6 jam', '', 1),
(3, 'Flying Fox: Meluncur dengan tali dari ketinggian 8 meter dan panjang 100 m.', 'Melatih keberanian menguji adrenalin', 'Termasuk dalam rangkaian paket', '', 2),
(3, 'Sharing game outbound: Sharing hasil outbound dengan peserta.', 'Evaluasi & Internalisasi nilai kelompok', 'Participant: SMP dan SMA', '', 3);

-- ---- Kategori + baris: Outbound Kids (4 kategori: A-D) ----
INSERT INTO `outbound_categories` (`id`, `package_id`, `title`, `col1_label`, `col2_label`, `col3_label`, `col4_label`, `sort_order`) VALUES
(4, 3, 'A. Ice Breaking', 'Nama Game', 'Learning & Goal', 'Durasi', 'Penjelasan Tambahan', 0),
(5, 3, 'B. Game', 'Nama Game & Deskripsi Singkat', 'Learning & Goal', 'Durasi', 'Keterangan Tambahan', 1),
(6, 3, 'C. Highropes Game', 'Nama Wahana', 'Learning & Goal', 'Durasi', 'Keterangan Tambahan', 2),
(7, 3, 'D. Alternative Game', 'Nama Wahana Pilihan / Substitusi', 'Learning & Goal', 'Durasi', 'Keterangan Tambahan', 3);

INSERT INTO `outbound_category_rows` (`category_id`, `col1`, `col2`, `col3`, `col4`, `sort_order`) VALUES
(4, 'Chicken Dance', 'Mencairkan suasana awal anak-anak', '±15 Menit', 'Game ini untuk mencairkan suasana dan membangun interaksi peserta dengan peserta juga dengan fasilitator.', 0),
(4, 'People to people', 'Melatih komunikasi antar teman sebaya', '±20 Menit', 'Diharapkan bisa terjadi hubungan aktif antara anak dan instruktur.', 1),
(4, 'Dance Gorilla', 'Melatih motorik kasar dan ketangkasan fisik anak', '±15 Menit', 'Game ini untuk mencairkan suasana dan membangun interaksi peserta dengan peserta juga dengan fasilitator.', 2),
(4, 'Brands Game', 'Melatih fokus indra pendengaran anak', '±20 Menit', 'Diharapkan bisa terjadi hubungan aktif antara anak dan instruktur.', 3),

(5, 'Ufo Alien: Memindahkan bola diatas nampan dari satu tempat ke tempat lain.', 'Melatih Konsentrasi', '±30 Menit', 'Media ramah anak (bola ringan)', 0),
(5, 'Ball and Pipe: Memindahkan bola pingpong dengan menggunakan paralon dari satu tempat ke tempat lain.', 'Tanggung Jawab', '±30 Menit', 'Melatih kesabaran antrean kelompok', 1),
(5, 'Labirin: Berusaha memasukkan bola pada sebuah lubang.', 'Leadership Inisiatif', '±25 Menit', 'Melatih arah komunikasi verbal anak', 2),
(5, 'Mini Water Tower: Berusaha mengisi air dalam paralon yang terdapat lubang-lubang kecil hingga penuh.', 'Totalitas Strategi', '±40 Menit', 'Disarankan membawa pakaian ganti', 3),

(6, 'Burma V', 'Melatih keberanian menguji adrenalin anak sejak dini', 'Sesuai Alur Antrean', 'Bermain ketangkasan di atas ketinggian menggunakan alat pengaman full body harness standar keselamatan internasional.', 0),
(6, 'Bridge Wood', 'Melatih keberanian menguji adrenalin anak sejak dini', 'Sesuai Alur Antrean', 'Bermain ketangkasan di atas ketinggian menggunakan alat pengaman full body harness standar keselamatan internasional.', 1),
(6, 'Flying Fox', 'Melatih keberanian menguji adrenalin anak sejak dini', 'Sesuai Alur Antrean', 'Bermain ketangkasan di atas ketinggian menggunakan alat pengaman full body harness standar keselamatan internasional.', 2),

(7, 'Ball Transfer', 'Melatih keberanian menguji adrenalin serta adaptasi alami anak', '±30 Menit', 'Alternative game khusus anak usia dini (TK). Aktivitas interaktif menanam tanaman buah serta interaksi langsung dengan ekosistem alam kebun.', 0),
(7, 'Redmood Ring', 'Melatih keberanian menguji adrenalin serta adaptasi alami anak', '±25 Menit', 'Alternative game khusus anak usia dini (TK). Aktivitas interaktif menanam tanaman buah serta interaksi langsung dengan ekosistem alam kebun.', 1),
(7, 'Jagur', 'Melatih keberanian menguji adrenalin serta adaptasi alami anak', '±20 Menit', 'Alternative game khusus anak usia dini (TK). Aktivitas interaktif menanam tanaman buah serta interaksi langsung dengan ekosistem alam kebun.', 2),
(7, 'Tangkap Ikan', 'Melatih keberanian menguji adrenalin serta adaptasi alami anak', '±45 Menit', 'Alternative game khusus anak usia dini (TK). Aktivitas interaktif menanam tanaman buah serta interaksi langsung dengan ekosistem alam kebun.', 3),
(7, 'Tanam Strawberry', 'Melatih keberanian menguji adrenalin serta adaptasi alami anak', '±40 Menit', 'Alternative game khusus anak usia dini (TK). Aktivitas interaktif menanam tanaman buah serta interaksi langsung dengan ekosistem alam kebun.', 4);
