<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini di: application/models/SiteImage_model.php

class SiteImage_model extends CI_Model
{
    protected $table = 'site_images';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->order_by('display_order', 'ASC')->get($this->table)->result_array();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id' => $id])->row_array();
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }
}
