<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini di: application/models/Setting_model.php

class Setting_model extends CI_Model
{
    protected $table = 'settings';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Settings cuma 1 baris, ambil baris pertama (buat kalau belum ada)
    public function get()
    {
        $row = $this->db->get($this->table)->row_array();
        if (!$row) {
            $this->db->insert($this->table, [
                'maintenance_mode' => 0,
                'email_notifications' => 1,
                'currency' => 'IDR',
                'decimal_places' => 0
            ]);
            $row = $this->db->get($this->table)->row_array();
        }
        return $row;
    }

    public function save($data)
    {
        $row = $this->get();
        $this->db->where('id', $row['id']);
        return $this->db->update($this->table, $data);
    }
}
