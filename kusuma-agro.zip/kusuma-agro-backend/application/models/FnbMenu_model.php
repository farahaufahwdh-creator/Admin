<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini di: application/models/FnbMenu_model.php

class FnbMenu_model extends CI_Model
{
    protected $table = 'fnb_menu_items';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->order_by('venue', 'ASC')->order_by('display_order', 'ASC')->get($this->table)->result_array();
    }

    public function get_by_venue($venue)
    {
        return $this->db->where('venue', $venue)->order_by('display_order', 'ASC')->get($this->table)->result_array();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, ['id' => $id])->row_array();
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
}