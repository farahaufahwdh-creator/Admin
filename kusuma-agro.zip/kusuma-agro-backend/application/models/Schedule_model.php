<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// GANTI TOTAL isi application/models/Schedule_model.php dengan ini

class Schedule_model extends CI_Model
{
    protected $table = 'schedule_events';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->order_by('event_date', 'ASC')->order_by('id', 'ASC')->get($this->table)->result_array();
    }

    public function get_by_date($date)
    {
        return $this->db->where('event_date', $date)->order_by('id', 'ASC')->get($this->table)->result_array();
    }

    public function get_by_month($year, $month)
    {
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end = date('Y-m-t', strtotime($start)); // tanggal terakhir bulan itu
        return $this->db->where('event_date >=', $start)
                         ->where('event_date <=', $end)
                         ->order_by('event_date', 'ASC')
                         ->get($this->table)
                         ->result_array();
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
}