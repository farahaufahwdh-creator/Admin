<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| OpsStats_model.php
| -------------------------------------------------------------------------
| Taruh file ini di: application/models/OpsStats_model.php
| Load di controller dengan: $this->load->model('OpsStats_model');
|
| Tabel single-row (selalu id=1), sama pola seperti tabel `settings`.
*/

class OpsStats_model extends CI_Model
{
    private $table = 'ops_stats';

    public function __construct()
    {
        parent::__construct();
    }

    // Ambil baris id=1. Kalau belum ada (misal migrasi belum jalan lengkap),
    // otomatis dibuatkan default supaya endpoint tidak pernah 404.
    public function get()
    {
        $row = $this->db->where('id', 1)->get($this->table)->row();
        if (!$row) {
            $this->db->insert($this->table, [
                'id' => 1,
                'daily_group_target' => 8,
                'staff_on_site' => 0,
            ]);
            $row = $this->db->where('id', 1)->get($this->table)->row();
        }
        return $row;
    }

    public function update($data)
    {
        // pastikan baris id=1 ada dulu
        $this->get();
        $this->db->where('id', 1)->update($this->table, $data);
        return $this->get();
    }
}
