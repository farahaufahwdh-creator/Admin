<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| HarvestSchedule_model.php
| -------------------------------------------------------------------------
| Taruh file ini di: application/models/HarvestSchedule_model.php
| Load di controller dengan: $this->load->model('HarvestSchedule_model');
*/

class HarvestSchedule_model extends CI_Model
{
    private $table = 'harvest_schedules';

    public function __construct()
    {
        parent::__construct();
    }

    public function get_all()
    {
        return $this->db->order_by('start_date', 'ASC')
                         ->get($this->table)
                         ->result();
    }

    public function get_by_id($id)
    {
        return $this->db->where('id', $id)
                         ->get($this->table)
                         ->row();
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id)->update($this->table, $data);
        return $this->get_by_id($id);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }
}
