<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini di: application/models/OutboundPackage_model.php

class OutboundPackage_model extends CI_Model
{
    protected $table = 'outbound_packages';
    protected $cat_table = 'outbound_categories';
    protected $row_table = 'outbound_category_rows';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        $packages = $this->db->order_by('display_order', 'ASC')->get($this->table)->result_array();
        foreach ($packages as &$p) {
            $p['categories'] = $this->get_categories($p['id']);
        }
        return $packages;
    }

    public function get_by_id($id)
    {
        $p = $this->db->get_where($this->table, ['id' => $id])->row_array();
        if ($p) $p['categories'] = $this->get_categories($id);
        return $p;
    }

    public function get_categories($package_id)
    {
        $cats = $this->db->where('package_id', $package_id)
                          ->order_by('sort_order', 'ASC')
                          ->get($this->cat_table)
                          ->result_array();
        foreach ($cats as &$c) {
            $c['rows'] = $this->db->where('category_id', $c['id'])
                                   ->order_by('sort_order', 'ASC')
                                   ->get($this->row_table)
                                   ->result_array();
        }
        return $cats;
    }

    public function create($data)
    {
        $categories = $data['categories'] ?? [];
        unset($data['categories']);

        $this->db->insert($this->table, $data);
        $id = $this->db->insert_id();

        $this->save_categories($id, $categories);
        return $id;
    }

    public function update($id, $data)
    {
        $categories = null;
        if (array_key_exists('categories', $data)) {
            $categories = $data['categories'];
            unset($data['categories']);
        }

        if (!empty($data)) {
            $this->db->where('id', $id);
            $this->db->update($this->table, $data);
        }

        if ($categories !== null) {
            $this->save_categories($id, $categories);
        }
        return true;
    }

    // Hapus semua kategori (+ baris ikut lewat FK cascade) punya paket ini, ganti baru
    public function save_categories($package_id, $categories)
    {
        $oldCatIds = $this->db->select('id')->where('package_id', $package_id)->get($this->cat_table)->result_array();
        if (!empty($oldCatIds)) {
            $ids = array_column($oldCatIds, 'id');
            $this->db->where_in('id', $ids)->delete($this->cat_table);
        }

        foreach ($categories as $ci => $cat) {
            $this->db->insert($this->cat_table, [
                'package_id' => $package_id,
                'title'      => $cat['title'] ?? '',
                'col1_label' => $cat['col1_label'] ?? 'Nama Game',
                'col2_label' => $cat['col2_label'] ?? 'Learning & Goal',
                'col3_label' => $cat['col3_label'] ?? 'Durasi',
                'col4_label' => $cat['col4_label'] ?? 'Keterangan',
                'sort_order' => $ci,
            ]);
            $catId = $this->db->insert_id();

            foreach (($cat['rows'] ?? []) as $ri => $row) {
                $this->db->insert($this->row_table, [
                    'category_id' => $catId,
                    'col1'        => $row['col1'] ?? '',
                    'col2'        => $row['col2'] ?? '',
                    'col3'        => $row['col3'] ?? '',
                    'col4'        => $row['col4'] ?? '',
                    'sort_order'  => $ri,
                ]);
            }
        }
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
        // categories & rows ikut terhapus otomatis (FOREIGN KEY ON DELETE CASCADE)
    }
}
