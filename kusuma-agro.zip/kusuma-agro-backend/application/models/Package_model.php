<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// GANTI TOTAL isi application/models/Package_model.php dengan ini

class Package_model extends CI_Model
{
    protected $table = 'packages';
    protected $rows_table = 'package_price_rows';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
    // 1. Ambil data paket utama
    $this->db->order_by('display_order', 'ASC');
    $packages = $this->db->get('packages')->result_array();

    // 2. Tarik data gambar & baris harga secara dinamis dan aman
    foreach ($packages as &$pkg) {
        // Ambil data dari tabel package_images (jika ada)
        if ($this->db->table_exists('package_images')) {
            $this->db->where('package_id', $pkg['id']);
            $images = $this->db->get('package_images')->result_array();
            $pkg['gallery_images'] = !empty($images) ? array_column($images, 'image_url') : [];
        } else {
            $pkg['gallery_images'] = [];
        }
        
        // KUNCI KEBAL ERROR: Cek otomatis mana nama tabel yang benar di database kamu
        if ($this->db->table_exists('packages_rows')) {
            $this->db->where('package_id', $pkg['id']);
            $pkg['rows'] = $this->db->get('packages_rows')->result_array();
        } elseif ($this->db->table_exists('package_rows')) {
            $this->db->where('package_id', $pkg['id']);
            $pkg['rows'] = $this->db->get('package_rows')->result_array();
        } else {
            // Jika dua-duanya tidak ketemu, buat array kosong agar front-end tidak rusak
            $pkg['rows'] = [];
        }
    }

    return $packages;
    }

    public function get_by_id($id)
    {
        $pkg = $this->db->get_where($this->table, ['id' => $id])->row_array();
        if ($pkg) {
            $pkg['rows'] = $this->get_rows($id);
        }
        return $pkg;
    }

    public function get_by_slug($slug)
    {
        $pkg = $this->db->get_where($this->table, ['slug' => $slug])->row_array();
        if ($pkg) {
            $pkg['rows'] = $this->get_rows($pkg['id']);
        }
        return $pkg;
    }

    public function get_rows($package_id)
    {
        return $this->db->where('package_id', $package_id)
                         ->order_by('sort_order', 'ASC')
                         ->get($this->rows_table)
                         ->result_array();
    }

    public function create($data)
    {
        $rows = $data['rows'] ?? [];
        unset($data['rows']);

        $this->db->insert($this->table, $data);
        $id = $this->db->insert_id();

        $this->save_rows($id, $rows);
        return $id;
    }

    public function update($id, $data)
    {
        $rows = null;
        if (array_key_exists('rows', $data)) {
            $rows = $data['rows'];
            unset($data['rows']);
        }

        if (!empty($data)) {
            $this->db->where('id', $id);
            $this->db->update($this->table, $data);
        }

        if ($rows !== null) {
            $this->save_rows($id, $rows);
        }
        return true;
    }

    // Hapus semua baris lama punya paket ini, ganti dengan baris baru
    public function save_rows($package_id, $rows)
    {
        $this->db->where('package_id', $package_id)->delete($this->rows_table);

        foreach ($rows as $i => $row) {
            $this->db->insert($this->rows_table, [
                'package_id' => $package_id,
                'col1'       => $row['col1'] ?? '',
                'col2'       => $row['col2'] ?? '',
                'col3'       => $row['col3'] ?? '',
                'col4'       => $row['col4'] ?? '',
                'sort_order' => $i,
            ]);
        }
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
        // package_price_rows ikut terhapus otomatis (FOREIGN KEY ON DELETE CASCADE)
    }
}