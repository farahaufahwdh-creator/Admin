<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// GANTI TOTAL isi application/controllers/api/Facilities.php dengan ini

class Facilities extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Facility_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    public function index($id = null)
    {
        if ($this->input->method() === 'get') {
            if ($id) {
                $f = $this->Facility_model->get_by_id($id);
                if (!$f) return $this->json(['error' => 'Fasilitas tidak ditemukan'], 404);
                return $this->json($f);
            }
            return $this->json($this->Facility_model->get_all());
        }

        if ($this->input->method() === 'post') return $this->create();
        if ($this->input->method() === 'put') return $this->update($id);
        if ($this->input->method() === 'delete') return $this->delete($id);
    }

    public function create()
    {
        $input = $this->get_json_body();
        $data = [
            'name'          => $input['name'] ?? '',
            'zone'          => $input['zone'] ?? null,
            'capacity'      => $input['capacity'] ?? '',
            'price'         => (int)($input['price'] ?? 0),
            'unit_label'    => $input['unit_label'] ?? 'Orang',
            'status'        => $input['status'] ?? 'available',
            'display_order' => (int)($input['display_order'] ?? 0),
        ];
        $newId = $this->Facility_model->create($data);
        return $this->json($this->Facility_model->get_by_id($newId), 201);
    }

    public function update($id)
    {
        $input = $this->get_json_body();
        $data = [];
        foreach (['name','zone','capacity','unit_label','status'] as $f) {
            if (array_key_exists($f, $input)) $data[$f] = $input[$f];
        }
        if (array_key_exists('price', $input)) $data['price'] = (int)$input['price'];
        if (array_key_exists('display_order', $input)) $data['display_order'] = (int)$input['display_order'];

        $this->Facility_model->update($id, $data);
        return $this->json($this->Facility_model->get_by_id($id));
    }

    public function delete($id)
    {
        $this->Facility_model->delete($id);
        return $this->json(['success' => true]);
    }
}