<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini (rename jadi Settings.php) di: application/controllers/api/Settings.php

class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Setting_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // GET  /api/settings  -> ambil konfigurasi
    // PUT  /api/settings  -> simpan konfigurasi
    public function index()
    {
        $method = $this->input->method();

        if ($method === 'get') {
            return $this->json($this->Setting_model->get());
        }

        if ($method === 'put' || $method === 'post') {
            $input = $this->get_json_body();
            $data = [
                'maintenance_mode'     => (int)($input['maintenance_mode'] ?? 0),
                'email_notifications'  => (int)($input['email_notifications'] ?? 1),
                'currency'             => $input['currency'] ?? 'IDR',
                'decimal_places'       => (int)($input['decimal_places'] ?? 0),
            ];
            $this->Setting_model->save($data);
            return $this->json($this->Setting_model->get());
        }
    }
}
