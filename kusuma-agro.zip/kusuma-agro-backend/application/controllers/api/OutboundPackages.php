<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini (rename jadi Outboundpackages.php -- huruf besar cuma di awal!)
// di: application/controllers/api/Outboundpackages.php

class Outboundpackages extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('OutboundPackage_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private function extract_fields($input)
    {
        $data = [];
        foreach (['slug','name','short_desc','facilities_note','min_pax_note','duration_note','cart_subtitle'] as $f) {
            if (array_key_exists($f, $input)) $data[$f] = $input[$f];
        }
        if (array_key_exists('display_order', $input)) $data['display_order'] = (int)$input['display_order'];
        if (array_key_exists('categories', $input)) $data['categories'] = $input['categories'];
        return $data;
    }

    // GET  /api/outbound-packages          -> semua paket (+ categories + rows)
    // GET  /api/outbound-packages/(id)     -> satu paket
    public function index($id = null)
    {
        if ($this->input->method() === 'get') {
            if ($id) {
                $p = $this->OutboundPackage_model->get_by_id($id);
                if (!$p) return $this->json(['error' => 'Paket tidak ditemukan'], 404);
                return $this->json($p);
            }
            return $this->json($this->OutboundPackage_model->get_all());
        }

        if ($this->input->method() === 'post') return $this->create();
        if ($this->input->method() === 'put') return $this->update($id);
        if ($this->input->method() === 'delete') return $this->delete($id);
    }

    public function create()
    {
        $input = $this->get_json_body();
        $data = $this->extract_fields($input);
        $data['name'] = $data['name'] ?? '';
        $data['slug'] = $data['slug'] ?? ('ob-paket-' . time());

        $newId = $this->OutboundPackage_model->create($data);
        return $this->json($this->OutboundPackage_model->get_by_id($newId), 201);
    }

    public function update($id)
    {
        $input = $this->get_json_body();
        $data = $this->extract_fields($input);

        $this->OutboundPackage_model->update($id, $data);
        return $this->json($this->OutboundPackage_model->get_by_id($id));
    }

    public function delete($id)
    {
        $this->OutboundPackage_model->delete($id);
        return $this->json(['success' => true]);
    }
}
