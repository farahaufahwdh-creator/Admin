<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// GANTI TOTAL isi application/controllers/api/Packages.php dengan ini

class Packages extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Package_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private function extract_fields($input)
    {
    $data = [];
    $fields = [
        'name', 'slug', 'short_desc', 'badge', 'effective_date',
        'cart_subtitle', 'min_pax_note', 'col1_label', 'col2_label', 'col3_label', 'col4_label'
    ];
    foreach ($fields as $f) {
        if (array_key_exists($f, $input)) $data[$f] = $input[$f];
    }
    if (array_key_exists('is_featured', $input)) $data['is_featured'] = (int)$input['is_featured'];
    if (array_key_exists('display_order', $input)) $data['display_order'] = (int)$input['display_order'];
    if (array_key_exists('rows', $input)) $data['rows'] = $input['rows'];
    
    // TAMBAHKAN INI: Agar array galeri foto ikut terekstrak dari JSON input CMS
    if (array_key_exists('gallery_images', $input)) $data['gallery_images'] = $input['gallery_images'];
    
    return $data;
    }

    // GET  /api/packages          -> daftar semua paket (+ rows tiap paket), urut display_order
    // GET  /api/packages/(id)     -> ambil satu paket (+ rows)
    public function index($id = null)
    {
        if ($this->input->method() === 'get') {
            if ($id) {
                $pkg = $this->Package_model->get_by_id($id);
                if (!$pkg) return $this->json(['error' => 'Paket tidak ditemukan'], 404);
                return $this->json($pkg);
            }
            return $this->json($this->Package_model->get_all());
        }

        if ($this->input->method() === 'post') return $this->create();
        if ($this->input->method() === 'put') return $this->update($id);
        if ($this->input->method() === 'delete') return $this->delete($id);
    }

    // POST /api/packages
    public function create()
    {
        $input = $this->get_json_body();
        $data = $this->extract_fields($input);

        $data['name']       = $data['name'] ?? '';
        $data['slug']       = $data['slug'] ?? ('paket-' . time());
        $data['col1_label'] = $data['col1_label'] ?? 'Package';
        $data['col2_label'] = $data['col2_label'] ?? 'Facility';
        $data['col3_label'] = $data['col3_label'] ?? 'Rate';
        $data['col4_label'] = $data['col4_label'] ?? 'Information';

        $newId = $this->Package_model->create($data);
        return $this->json($this->Package_model->get_by_id($newId), 201);
    }

    // PUT /api/packages/(id)
    public function update($id)
    {
        $input = $this->get_json_body();
        $data = $this->extract_fields($input);

        $this->Package_model->update($id, $data);
        return $this->json($this->Package_model->get_by_id($id));
    }

    // DELETE /api/packages/(id)
    public function delete($id)
    {
        $this->Package_model->delete($id);
        return $this->json(['success' => true]);
    }
}