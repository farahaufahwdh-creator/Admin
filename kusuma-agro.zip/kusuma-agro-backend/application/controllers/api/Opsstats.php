<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Opsstats.php (controller)
| -------------------------------------------------------------------------
| Taruh file ini di: application/controllers/api/Opsstats.php
| Cocok dengan route di routes.php:
|   $route['api/ops-stats'] = 'api/opsstats/index';
|
| GET  /api/ops-stats -> ambil { daily_group_target, staff_on_site, updated_at }
| PUT  /api/ops-stats -> update sebagian/semua field di atas
|
| PENTING: samakan bagian CORS di bawah dengan controller api/ lain kamu
| kalau caranya berbeda (misal ditangani lewat hooks.php / MY_Controller).
*/

class Opsstats extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('OpsStats_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, PUT, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Content-Type: application/json');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    public function index()
    {
        $method = $this->input->method();

        if ($method === 'get') {
            echo json_encode($this->OpsStats_model->get());
            return;
        }

        if ($method === 'put') {
            $input = json_decode($this->input->raw_input_stream, true) ?? [];
            $data = [];
            if (array_key_exists('daily_group_target', $input)) {
                $data['daily_group_target'] = (int) $input['daily_group_target'];
            }
            if (array_key_exists('staff_on_site', $input)) {
                $data['staff_on_site'] = (int) $input['staff_on_site'];
            }

            if (empty($data)) {
                http_response_code(400);
                echo json_encode(['error' => 'Tidak ada field valid untuk diupdate']);
                return;
            }

            echo json_encode($this->OpsStats_model->update($data));
            return;
        }

        http_response_code(405);
        echo json_encode(['error' => 'Method tidak didukung']);
    }
}
