<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// ⚠️ PENTING: rename file ini jadi "Fnbmenu.php" (huruf besar CUMA di awal),
// taruh di: application/controllers/api/Fnbmenu.php
// Kalau filenya dinamai "FnbMenu.php" (huruf M besar di tengah), rutenya akan
// "Not Found" di server Linux (case-sensitive) walau jalan normal di Laragon/Windows.

class Fnbmenu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('FnbMenu_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // GET /api/fnb-menu               -> semua item (semua venue)
    // GET /api/fnb-menu/(id)          -> satu item
    // POST /api/fnb-menu              -> tambah item baru (venue dikirim di body)
    // PUT /api/fnb-menu/(id)          -> update item
    // DELETE /api/fnb-menu/(id)       -> hapus item
    public function index($id = null)
    {
        $method = $this->input->method();

        if ($method === 'get') {
            if ($id) {
                $item = $this->FnbMenu_model->get_by_id($id);
                if (!$item) return $this->json(['error' => 'Menu tidak ditemukan'], 404);
                return $this->json($item);
            }
            return $this->json($this->FnbMenu_model->get_all());
        }

        if ($method === 'post') {
            $input = $this->get_json_body();
            $data = [
                'venue'        => $input['venue'] ?? '',
                'name'         => $input['name'] ?? '',
                'desc'         => $input['desc'] ?? '',
                'category'     => $input['category'] ?? '',
                'price'        => (int)($input['price'] ?? 0),
                'stock'        => (int)($input['stock'] ?? 0),
                'status'       => $input['status'] ?? 'available',
                'is_promo'     => (int)($input['isPromo'] ?? 0),
                'is_low_stock' => (int)($input['isLowStock'] ?? 0),
                'today_sold'   => (int)($input['todaySold'] ?? 0),
            ];
            $newId = $this->FnbMenu_model->create($data);
            return $this->json($this->FnbMenu_model->get_by_id($newId), 201);
        }

        if ($method === 'put') {
            $input = $this->get_json_body();
            // map nama field JS -> nama kolom DB (kalau ada perbedaan penamaan)
            $map = [
                'isPromo'     => 'is_promo',
                'isLowStock'  => 'is_low_stock',
                'todaySold'   => 'today_sold',
            ];
            $data = [];
            foreach ($input as $key => $val) {
                $data[$map[$key] ?? $key] = $val;
            }
            $this->FnbMenu_model->update($id, $data);
            return $this->json($this->FnbMenu_model->get_by_id($id));
        }

        if ($method === 'delete') {
            $this->FnbMenu_model->delete($id);
            return $this->json(['success' => true]);
        }
    }
}
