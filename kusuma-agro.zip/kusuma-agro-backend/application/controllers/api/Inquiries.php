<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini (rename jadi Inquiries.php) di: application/controllers/api/Inquiries.php

class Inquiries extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Inquiry_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // GET    /api/inquiries       -> semua inquiry (terbaru duluan)
    // POST   /api/inquiries       -> kirim inquiry baru (dipakai situs publik)
    // PUT    /api/inquiries/(id)  -> update status (dipakai CMS)
    // DELETE /api/inquiries/(id)  -> hapus
    public function index($id = null)
    {
        $method = $this->input->method();

        if ($method === 'get') {
            return $this->json($this->Inquiry_model->get_all());
        }

        if ($method === 'post') {
            $input = $this->get_json_body();
            $data = [
                'type'          => $input['type'] ?? 'contact',
                'name'          => $input['name'] ?? null,
                'email'         => $input['email'] ?? null,
                'phone'         => $input['phone'] ?? null,
                'message'       => $input['message'] ?? null,
                'items_summary' => $input['items_summary'] ?? null,
                'status'        => 'new',
            ];
            $newId = $this->Inquiry_model->create($data);
            return $this->json($this->Inquiry_model->get_by_id($newId), 201);
        }

        if ($method === 'put') {
            $input = $this->get_json_body();
            $data = [];
            if (array_key_exists('status', $input)) $data['status'] = $input['status'];
            $this->Inquiry_model->update($id, $data);
            return $this->json($this->Inquiry_model->get_by_id($id));
        }

        if ($method === 'delete') {
            $this->Inquiry_model->delete($id);
            return $this->json(['success' => true]);
        }
    }
}
