<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// GANTI TOTAL isi application/controllers/api/Schedule.php dengan ini

class Schedule extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Schedule_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // GET    /api/schedule                       -> semua jadwal
    // GET    /api/schedule?date=2026-07-17        -> jadwal 1 hari tertentu
    // GET    /api/schedule?year=2026&month=7      -> jadwal 1 bulan tertentu
    // POST   /api/schedule                        -> tambah jadwal baru
    // DELETE /api/schedule/(id)                   -> hapus jadwal
    public function index($id = null)
    {
        $method = $this->input->method();

        if ($method === 'get') {
            $date = $this->input->get('date');
            $year = $this->input->get('year');
            $month = $this->input->get('month');

            if ($date) {
                return $this->json($this->Schedule_model->get_by_date($date));
            }
            if ($year && $month) {
                return $this->json($this->Schedule_model->get_by_month((int)$year, (int)$month));
            }
            return $this->json($this->Schedule_model->get_all());
        }

        if ($method === 'post') {
            $input = $this->get_json_body();
            $data = [
                'event_date' => $input['event_date'] ?? date('Y-m-d'),
                'time_label' => $input['time'] ?? '',
                'title'      => $input['title'] ?? '',
                'sub'        => $input['sub'] ?? '',
                'color'      => $input['color'] ?? '',
            ];
            $newId = $this->Schedule_model->create($data);
            return $this->json(['id' => $newId] + $data, 201);
        }

        if ($method === 'delete') {
            $this->Schedule_model->delete($id);
            return $this->json(['success' => true]);
        }
    }
}