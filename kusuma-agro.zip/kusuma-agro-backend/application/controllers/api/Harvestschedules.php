<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Harvestschedules.php (controller)
| -------------------------------------------------------------------------
| Taruh file ini di: application/controllers/api/Harvestschedules.php
| Cocok dengan route di routes.php:
|   $route['api/harvest-schedules']        = 'api/harvestschedules/index';
|   $route['api/harvest-schedules/(:num)'] = 'api/harvestschedules/index/$1';
|
| PENTING: kalau controller api/Fnbmenu.php atau api/Packages.php kamu
| menangani header CORS lewat cara lain (misalnya di hooks.php atau base
| controller MY_Controller), samakan bagian header CORS di bawah ini
| dengan cara yang sama, supaya konsisten dengan controller lain.
*/

class Harvestschedules extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('HarvestSchedule_model');

        // CORS -- samakan dengan controller api/ lain kalau caranya berbeda
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Content-Type: application/json');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    public function index($id = null)
    {
        $method = $this->input->method();

        switch ($method) {
            case 'get':
                if ($id) {
                    $row = $this->HarvestSchedule_model->get_by_id($id);
                    if (!$row) {
                        http_response_code(404);
                        echo json_encode(['error' => 'Jadwal panen tidak ditemukan']);
                        return;
                    }
                    echo json_encode($row);
                } else {
                    echo json_encode($this->HarvestSchedule_model->get_all());
                }
                break;

            case 'post':
                $input = json_decode($this->input->raw_input_stream, true);

                if (empty($input['fruit_name']) || empty($input['start_date']) || empty($input['end_date'])) {
                    http_response_code(400);
                    echo json_encode(['error' => 'fruit_name, start_date, dan end_date wajib diisi']);
                    return;
                }

                $data = [
                    'fruit_name' => $input['fruit_name'],
                    'start_date' => $input['start_date'],
                    'end_date'   => $input['end_date'],
                    'notes'      => $input['notes'] ?? null,
                ];

                $newId = $this->HarvestSchedule_model->create($data);
                http_response_code(201);
                echo json_encode($this->HarvestSchedule_model->get_by_id($newId));
                break;

            case 'put':
                if (!$id) {
                    http_response_code(400);
                    echo json_encode(['error' => 'ID wajib disertakan untuk update']);
                    return;
                }

                $input = json_decode($this->input->raw_input_stream, true);
                $data = [];
                foreach (['fruit_name', 'start_date', 'end_date', 'notes'] as $field) {
                    if (array_key_exists($field, $input)) {
                        $data[$field] = $input[$field];
                    }
                }

                $updated = $this->HarvestSchedule_model->update($id, $data);
                echo json_encode($updated);
                break;

            case 'delete':
                if (!$id) {
                    http_response_code(400);
                    echo json_encode(['error' => 'ID wajib disertakan untuk hapus']);
                    return;
                }
                $this->HarvestSchedule_model->delete($id);
                echo json_encode(['success' => true]);
                break;

            default:
                http_response_code(405);
                echo json_encode(['error' => 'Method tidak didukung']);
        }
    }
}
