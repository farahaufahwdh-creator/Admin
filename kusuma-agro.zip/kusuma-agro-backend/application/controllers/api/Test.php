<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini di: application/controllers/api/Test.php
// Ini CUMA untuk tes, tidak menyentuh database sama sekali.

class Test extends CI_Controller
{
    public function index()
    {
        echo 'OK - controller di dalam folder api/ berhasil ditemukan!';
    }
}
