<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Taruh file ini (rename jadi Siteimages.php -- huruf besar cuma di awal!)
// di: application/controllers/api/Siteimages.php

class Siteimages extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('SiteImage_model');

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, PUT, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    private function json($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_json_body()
    {
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    // GET /api/site-images        -> semua slot gambar
    // PUT /api/site-images/(id)   -> update image_url slot tertentu
    public function index($id = null)
    {
        if ($this->input->method() === 'get') {
            return $this->json($this->SiteImage_model->get_all());
        }

        if ($this->input->method() === 'put') {
            $input = $this->get_json_body();
            $data = [];
            if (array_key_exists('image_url', $input)) $data['image_url'] = $input['image_url'];
            $this->SiteImage_model->update($id, $data);
            return $this->json($this->SiteImage_model->get_by_id($id));
        }
    }
}
