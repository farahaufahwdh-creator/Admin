<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| Ini file routes.php LENGKAP -- timpa/replace total file
| application/config/routes.php kamu dengan isi ini (jangan cuma disisipkan
| sebagian), supaya konfigurasi default CodeIgniter tetap ada.
*/

$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// ============================================================
// API ROUTES - Kusuma Agro CMS
// ============================================================

// Packages
$route['api/packages']            = 'api/packages/index';
$route['api/packages/(:num)']     = 'api/packages/index/$1';

// Outbound & Facilities
$route['api/facilities']          = 'api/facilities/index';
$route['api/facilities/(:num)']   = 'api/facilities/index/$1';

// Group Schedule (sidebar Outbound)
$route['api/schedule']            = 'api/schedule/index';
$route['api/schedule/(:num)']     = 'api/schedule/index/$1';

// Outbound Packages (detail game per kategori)
$route['api/outbound-packages']          = 'api/outboundpackages/index';
$route['api/outbound-packages/(:num)']   = 'api/outboundpackages/index/$1';

// Upload gambar
$route['api/upload'] = 'api/upload/index';

// Site Images (galeri/hero/dll di seluruh halaman)
$route['api/site-images']          = 'api/siteimages/index';
$route['api/site-images/(:num)']   = 'api/siteimages/index/$1';

// Inquiries (kontak + riwayat checkout keranjang WA)
$route['api/inquiries']            = 'api/inquiries/index';
$route['api/inquiries/(:num)']     = 'api/inquiries/index/$1';

// F&B Menu (semua venue, controller file: Fnbmenu.php / class Fnbmenu)
$route['api/fnb-menu']            = 'api/fnbmenu/index';
$route['api/fnb-menu/(:num)']     = 'api/fnbmenu/index/$1';

// Harvest Schedule (link "Manage Harvest Schedule" di tab F&B Menu)
$route['api/harvest-schedules']          = 'api/harvestschedules/index';
$route['api/harvest-schedules/(:num)']   = 'api/harvestschedules/index/$1';

// Ops Stats (Equipment Health, Today's Load, Staff On-Site di tab Outbound)
$route['api/ops-stats']            = 'api/opsstats/index';

// Settings (single row)
$route['api/settings']            = 'api/settings/index';