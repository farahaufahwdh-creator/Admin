-- Tambah kolom tanggal ke jadwal grup (supaya bisa ditampilkan per bulan di kalender)
ALTER TABLE `schedule_events`
  ADD COLUMN `event_date` DATE DEFAULT NULL AFTER `id`;

-- Isi tanggal untuk data contoh yang sudah ada (set ke hari ini biar tetap muncul di "Upcoming Today")
UPDATE `schedule_events` SET `event_date` = CURDATE() WHERE `event_date` IS NULL;
