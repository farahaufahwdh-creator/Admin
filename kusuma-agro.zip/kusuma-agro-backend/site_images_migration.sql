-- ============================================================
-- TABEL: site_images — semua slot gambar dekoratif di situs
-- (di luar Packages & F&B yang sudah punya field gambar sendiri)
-- ============================================================

CREATE TABLE IF NOT EXISTS `site_images` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `image_key` VARCHAR(60) NOT NULL UNIQUE,
  `label` VARCHAR(150) NOT NULL,
  `alt_match` VARCHAR(255) NOT NULL, -- dipakai script untuk cari <img alt="..."> yang cocok
  `image_url` VARCHAR(255) NOT NULL,
  `group_name` VARCHAR(50) NOT NULL,
  `display_order` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `site_images` (`image_key`, `label`, `alt_match`, `image_url`, `group_name`, `display_order`) VALUES
('hero_waterpark', 'Hero - Kartu Waterpark', 'Wahana waterpark seluncuran', 'https://picsum.photos/seed/waterpark-slide/600/800', 'Beranda', 1),
('hero_outbound', 'Hero - Kartu Outbound', 'Wahana outbound mini off-road', 'https://picsum.photos/seed/offroad-outbound/600/800', 'Beranda', 2),
('hero_foodcoffee', 'Hero - Kartu Food & Coffee', 'Hidangan khas Food and Coffee', 'https://picsum.photos/seed/apple-dish/600/800', 'Beranda', 3),

('philosophy_main', 'Cerita Kami - Foto Utama', 'Pengunjung memetik apel langsung dari pohon', 'https://picsum.photos/seed/apple-picking-woman/700/900', 'Beranda', 4),
('philosophy_inset', 'Cerita Kami - Foto Kecil (Inset)', 'Pemandangan kebun Kusuma Agrowisata', 'https://picsum.photos/seed/kusuma-hillside-view/500/380', 'Beranda', 5),

('gallery_1', 'Galeri - Foto 1', 'Pengunjung berjalan di jembatan kayu hutan', 'https://picsum.photos/seed/hiker-boardwalk/400/580', 'Galeri', 6),
('gallery_2', 'Galeri - Foto 2', 'Pintu masuk sanctuary bertuliskan Agrowisata', 'https://picsum.photos/seed/entrance-sign/400/580', 'Galeri', 7),
('gallery_3', 'Galeri - Foto 3', 'Detail daun pakis hijau', 'https://picsum.photos/seed/fern-macro/400/580', 'Galeri', 8),
('gallery_4', 'Galeri - Foto 4', 'Siluet lompatan di tebing saat senja', 'https://picsum.photos/seed/cliff-sunset/400/580', 'Galeri', 9),

('fc_hero', 'Food & Coffee - Foto Hero', 'Premium Coffee and Farm Concept', 'https://picsum.photos/seed/coffeehero/1400/800', 'Food & Coffee', 10),
('fc_split', 'Food & Coffee - Foto Cerita Kuliner', 'Kusuma Agrowisata Area', 'https://picsum.photos/seed/aboutmedia/700/600', 'Food & Coffee', 11),

('ob_hero', 'Outbound - Foto Hero', 'Kabut pagi di kawasan hutan outbound Kusuma Agrowisata', 'https://picsum.photos/seed/outbound-forest-mist/1600/1000', 'Outbound', 12),
('ob_experience', 'Outbound - Foto Our Experience', 'Peserta outbound menaiki mini off-road ATV', 'https://picsum.photos/seed/outbound-team-cabin/700/900', 'Outbound', 13),
('ob_gallery_main', 'Outbound - Galeri Foto Utama', 'Peserta mengendarai mini off-road buggy', 'https://picsum.photos/seed/atv-bw-outbound/700/900', 'Outbound', 14),
('ob_gallery_side1', 'Outbound - Galeri Foto Kecil 1', 'Peserta meluncur flying fox', 'https://picsum.photos/seed/flyingfox-jump/500/500', 'Outbound', 15),
('ob_gallery_side2', 'Outbound - Galeri Foto Kecil 2', 'Rombongan peserta outbound berfoto bersama', 'https://picsum.photos/seed/bonfire-circle-night/500/500', 'Outbound', 16),
('ob_gallery_wide', 'Outbound - Galeri Foto Panjang', 'Pemandangan area outbound Kusuma Agrowisata', 'https://picsum.photos/seed/aerial-outbound-camp/1400/500', 'Outbound', 17);
