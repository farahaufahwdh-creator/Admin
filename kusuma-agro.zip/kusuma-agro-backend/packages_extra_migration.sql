-- ============================================================
-- MIGRASI ULANG tabel packages (skema final, sesuai form CMS)
-- Jalankan SETELAH packages_table.sql pertama kali dibuat.
-- Kalau kamu SUDAH pernah import packages_table.sql yang lama,
-- jalankan dulu: DROP TABLE IF EXISTS packages, package_price_rows;
-- baru jalankan seluruh isi file ini.
-- ============================================================

DROP TABLE IF EXISTS `package_price_rows`;
DROP TABLE IF EXISTS `packages`;

CREATE TABLE `packages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `short_desc` TEXT DEFAULT NULL,
  `badge` VARCHAR(50) DEFAULT NULL,
  `effective_date` VARCHAR(50) DEFAULT NULL,
  `image_url` VARCHAR(255) DEFAULT NULL,
  `cart_subtitle` VARCHAR(150) DEFAULT NULL,
  `min_pax_note` VARCHAR(50) DEFAULT NULL,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `col1_label` VARCHAR(50) NOT NULL DEFAULT 'Package',
  `col2_label` VARCHAR(50) NOT NULL DEFAULT 'Facility',
  `col3_label` VARCHAR(50) NOT NULL DEFAULT 'Rate',
  `col4_label` VARCHAR(50) NOT NULL DEFAULT 'Information',
  `display_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `package_price_rows` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `package_id` INT UNSIGNED NOT NULL,
  `col1` VARCHAR(150) DEFAULT NULL,
  `col2` TEXT DEFAULT NULL,
  `col3` VARCHAR(100) DEFAULT NULL,
  `col4` VARCHAR(100) DEFAULT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Isi 4 paket ASLI sesuai konten situs kusumaagro.netlify.app
-- ============================================================
INSERT INTO `packages`
  (`id`, `name`, `slug`, `short_desc`, `badge`, `effective_date`, `image_url`, `cart_subtitle`, `min_pax_note`, `is_featured`, `col1_label`, `col2_label`, `col3_label`, `col4_label`, `display_order`)
VALUES
  (1, 'Wisata Petik Apel', 'detail-apel',
   'Petualangan memetik buah segar langsung dari pohon pilihan. Dilengkapi fasilitas snack tradisional, jus segar, hingga yogurt khas produksi Kusuma.',
   'Best Seller', '1 Juni 2016', 'https://picsum.photos/seed/big-apple/900/600',
   'Paket Kebun Apel Signature', NULL, 1,
   'Package', 'Facility', 'Weekday', 'Weekend', 1),

  (2, 'Wisata Petik Strawberry', 'detail-strawberry',
   'Pengalaman memetik buah strawberry premium berpadu hidangan strawberry pancake & milkshake segar.',
   NULL, '1 Januari 2015', 'https://picsum.photos/seed/small-strawberry/400/400',
   'Paket Premium Strawberry', NULL, 0,
   'Package', 'Facility', 'Weekday', 'Weekend', 2),

  (3, 'Paket Agro Edukasi', 'detail-edukasi',
   'Program edukasi interaktif budidaya tanaman hortikultura & hidroponik untuk pelajar hingga instansi.',
   NULL, '1 Januari 2015', 'https://picsum.photos/seed/small-edu/400/400',
   'Min. 30 Orang - Edukasi Terstruktur', 'Min. 30 Orang', 0,
   'Package', 'Facility', 'Rate', 'Information', 3),

  (4, 'Paket Study Tour (TK & SD)', 'detail-studytour',
   'Eksplorasi ceria khusus anak usia dini mengenal alam melalui petik buah terpandu dan welcome drink.',
   NULL, '1 Januari 2016', 'https://picsum.photos/seed/small-tour/400/400',
   'Khusus Anak Usia Dini - Min 30 Pax', 'Min. 30 Orang', 0,
   'Package', 'Facility', 'Rate', 'Information', 4);

INSERT INTO `package_price_rows` (`package_id`, `col1`, `col2`, `col3`, `col4`, `sort_order`) VALUES
(1, 'Paket Apel', 'Wisata petik 2 apel / jeruk / strw, petik 2 jambu, polo pendem, jus buah, yogurt.', 'Hubungi Kami', 'Hubungi Kami', 0),

(2, 'Paket Strawberry', 'Petik 4 buah strawberry, petik 2 buah jambu, pancake + milkshake strawberry, sayur hidroponik 1 pack, yogurt.', 'Hubungi Kami', 'Hubungi Kami', 0),

(3, 'Edukasi Pelajar', 'Wisata petik apel/jambu, juice, presentasi, proses produksi.', 'Hubungi Kami', 'Minimal 30 Orang', 0),
(3, 'Ekskul Biologi', 'Wisata petik apel/jambu, juice, presentasi hidroponik, bahan pelatihan, lunch box, sayur hidroponik 1 pack.', 'Hubungi Kami', 'Minimal 30 Orang', 1),
(3, 'Edukasi Instansi', 'Wisata petik apel/jambu, juice, presentasi agrowisata, lunch buffet, yogurt, hall.', 'Hubungi Kami', 'Minimal 30 Orang', 2),

(4, 'Paket Study Tour', 'Wisata petik apel / jambu, welcome drink yogurt. *Khusus untuk TK & SD.', 'Hubungi Kami', 'Minimal 30 Orang', 0);
