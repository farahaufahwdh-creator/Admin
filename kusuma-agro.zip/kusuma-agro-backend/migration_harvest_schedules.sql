-- ============================================================
-- Migrasi: tabel harvest_schedules
-- Dipakai oleh fitur "Manage Harvest Schedule" di tab F&B Menu CMS.
-- Jalankan query ini di database kusuma-agro kamu (HeidiSQL / phpMyAdmin / CLI).
-- ============================================================

CREATE TABLE IF NOT EXISTS `harvest_schedules` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fruit_name` VARCHAR(100) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `notes` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Contoh data awal (opsional, boleh dihapus)
INSERT INTO `harvest_schedules` (`fruit_name`, `start_date`, `end_date`, `notes`) VALUES
('Apel Manalagi', '2026-06-01', '2026-08-31', 'Panen raya kebun blok A'),
('Strawberry', '2026-05-01', '2026-09-30', 'Panen berkelanjutan sepanjang musim kemarau');
