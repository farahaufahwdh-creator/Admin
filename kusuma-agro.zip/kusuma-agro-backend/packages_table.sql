CREATE TABLE IF NOT EXISTS `packages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `desc` VARCHAR(255) DEFAULT NULL,
  `category` ENUM('AGRO','EDU') NOT NULL DEFAULT 'AGRO',
  `status` ENUM('in-season','available','low-stock','out-of-season') NOT NULL DEFAULT 'available',
  `price` INT UNSIGNED NOT NULL DEFAULT 0,
  `bookings` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Contoh data awal (opsional)
INSERT INTO `packages` (`name`, `desc`, `category`, `status`, `price`, `bookings`) VALUES
('Wisata Petik Apel', 'Seasonal picking tour in Sector A', 'AGRO', 'in-season', 25000, 320),
('Wisata Petik Strawberry', 'Greenhouse hydroponic experience', 'AGRO', 'low-stock', 35000, 210),
('Paket Agro Edukasi', 'Guided learning for schools (Min. 20 pax)', 'EDU', 'available', 75000, 180),
('Paket Study Tour', 'Full-day experience with lunch & souvenir', 'EDU', 'out-of-season', 125000, 90);
