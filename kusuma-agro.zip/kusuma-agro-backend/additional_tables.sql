-- Tabel Fasilitas Outbound
CREATE TABLE IF NOT EXISTS `facilities` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `zone` VARCHAR(150) DEFAULT NULL,
  `capacity` VARCHAR(100) DEFAULT NULL,
  `price` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('available','maintenance') NOT NULL DEFAULT 'available',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `facilities` (`name`, `zone`, `capacity`, `price`, `status`) VALUES
('Paintball War Game', 'Adventure Zone A', 'Min. 10 Pax', 150000, 'available'),
('ATV Jungle Track', 'Lower Forest Area', '1 Unit (2 Pax)', 250000, 'maintenance'),
('Flying Fox Zip', 'Valley View Point', '1 Pax', 75000, 'available'),
('Airsoft Tactical', 'Adventure Zone B', 'Min. 6 Pax', 120000, 'available');


-- Tabel Menu F&B (per venue)
CREATE TABLE IF NOT EXISTS `fnb_menu_items` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `venue` VARCHAR(50) NOT NULL, -- 'apple-house' | 'strawberry-house' | 'kedai-alamanda'
  `name` VARCHAR(150) NOT NULL,
  `desc` VARCHAR(255) DEFAULT NULL,
  `category` VARCHAR(50) DEFAULT NULL,
  `price` INT UNSIGNED NOT NULL DEFAULT 0,
  `stock` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('available','seasonal','out-of-stock') NOT NULL DEFAULT 'available',
  `is_promo` TINYINT(1) NOT NULL DEFAULT 0,
  `is_low_stock` TINYINT(1) NOT NULL DEFAULT 0,
  `today_sold` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `fnb_menu_items` (`venue`, `name`, `desc`, `category`, `price`, `stock`, `status`, `is_promo`, `is_low_stock`, `today_sold`) VALUES
('apple-house', 'Signature Apple Pie', 'Dipanggang segar setiap hari memakai apel pilihan dari kebun sendiri.', 'SIGNATURE', 35000, 45, 'available', 1, 0, 22),
('apple-house', 'Fresh Apple Juice', '100% jus cold-pressed alami tanpa tambahan gula atau pengawet.', 'BEVERAGE', 25000, 120, 'available', 0, 0, 40),
('apple-house', 'Strawberry Premium Pancake', 'Pancake lembut dengan topping stroberi segar.', 'OUT OF SEASON', 48000, 0, 'out-of-stock', 0, 1, 0),
('strawberry-house', 'Strawberry Cheesecake', 'Cheesecake lembut dengan lapisan stroberi segar dari kebun.', 'SIGNATURE', 32000, 18, 'available', 0, 1, 14),
('kedai-alamanda', 'Nasi Goreng Kampung', 'Nasi goreng khas dengan bahan baku agrikultur segar.', 'FOOD', 28000, 60, 'available', 1, 0, 30);


-- Tabel Jadwal Grup (Group Schedule - sidebar Outbound)
CREATE TABLE IF NOT EXISTS `schedule_events` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `time_label` VARCHAR(20) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `sub` VARCHAR(255) DEFAULT NULL,
  `color` VARCHAR(20) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `schedule_events` (`time_label`, `title`, `sub`, `color`) VALUES
('09:00 AM', 'Corporate Outbound - PT Mitra Jaya', '45 Pax • Paintball & ATV', 'c-green'),
('01:30 PM', 'Family Gathering - Grup B', '20 Pax • Flying Fox & Lunch', ''),
('03:00 PM', 'Study Tour SMA Harapan', '120 Pax • Full Facility Circuit', 'c-red');


-- Tabel Settings (cuma 1 baris konfigurasi umum)
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `maintenance_mode` TINYINT(1) NOT NULL DEFAULT 0,
  `email_notifications` TINYINT(1) NOT NULL DEFAULT 1,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'IDR',
  `decimal_places` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `settings` (`maintenance_mode`, `email_notifications`, `currency`, `decimal_places`) VALUES
(0, 1, 'IDR', 0);
