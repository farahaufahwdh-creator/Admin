-- ============================================================
-- Migrasi: tabel ops_stats
-- Dipakai oleh 3 kartu statistik di tab Outbound: Equipment Health
-- (dihitung otomatis dari Facilities, tidak disimpan di sini),
-- Today's Load (target harian) dan Staff On-Site (input manual).
-- Tabel single-row, sama seperti tabel `settings`.
-- ============================================================

CREATE TABLE IF NOT EXISTS `ops_stats` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `daily_group_target` INT UNSIGNED NOT NULL DEFAULT 8,
  `staff_on_site` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Baris tunggal (id=1), dibuat sekali. Controller juga otomatis membuat
-- baris ini kalau belum ada, jadi INSERT ini opsional/aman diulang.
INSERT INTO `ops_stats` (`id`, `daily_group_target`, `staff_on_site`)
VALUES (1, 8, 18)
ON DUPLICATE KEY UPDATE id = id;
